package ProjecteBolincheYBochinche.Services;

public enum Daus {
	UN,DOS,TRES,COR,DANY,ENERGIA
}
