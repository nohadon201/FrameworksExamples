package ProjecteBolincheYBochinche.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ProjecteBolincheYBochinche.Model.Partida;

public interface PartidaRepository extends JpaRepository<Partida,Integer>{

}