package ProjecteBolincheYBochinche.Model;

public enum CartesPoder {
	AlientoFuego, Mimetismo, RayoReductor, EscupidorVeneno
}
